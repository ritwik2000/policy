/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exavalu.com.beans;

/**
 *
 * @author RITWIK
 */
public class policyshow {
private int policyid;
private String policyname;
private String policycoverage;
private String maxage;
private String minage;

    /**
     * @return the policyid
     */
    public int getPolicyid() {
        return policyid;
    }

    /**
     * @param policyid the policyid to set
     */
    public void setPolicyid(int policyid) {
        this.policyid = policyid;
    }

    /**
     * @return the policyname
     */
    public String getPolicyname() {
        return policyname;
    }

    /**
     * @param policyname the policyname to set
     */
    public void setPolicyname(String policyname) {
        this.policyname = policyname;
    }

    /**
     * @return the policycoverage
     */
    public String getPolicycoverage() {
        return policycoverage;
    }

    /**
     * @param policycoverage the policycoverage to set
     */
    public void setPolicycoverage(String policycoverage) {
        this.policycoverage = policycoverage;
    }

    /**
     * @return the maxage
     */
    public String getMaxage() {
        return maxage;
    }

    /**
     * @param maxage the maxage to set
     */
    public void setMaxage(String maxage) {
        this.maxage = maxage;
    }

    /**
     * @return the minage
     */
    public String getMinage() {
        return minage;
    }

    /**
     * @param minage the minage to set
     */
    public void setMinage(String minage) {
        this.minage = minage;
    }
    
}
